var teste = 0

function lerinfo() {
  
  teste = teste + 1
  
  if (teste > 1) {
    document.getElementById('tbody').remove()
    var tbody = document.createElement("tbody")
    var table = document.querySelector("#table")
    tbody.id = "tbody"
    table.insertAdjacentElement("beforeend", tbody)
  }
  
  let valors = valor.value
  let saldo = valors * 1
  
  let taxas = taxa.value
  let taxan = taxas * 1
  
  let parcelat = parcela.value
  var parcelan = parcelat * 1
  parcelan = Math.round(parcelan)
  
  let parc = 0
 
  let amortizacao = saldo / parcelan
  
    calculo( parcelan, amortizacao, taxan, saldo, parc)
}
 
function calculo( parcelan, amortizacao, taxan, saldo, parc) {
 parc = parc + 1

  if (parcelan > 0) {
 let juros = saldo * (taxan / 100)
 juros = +(juros.toFixed(2))
 
 let vparcela = juros + amortizacao
 vparcela = +(vparcela.toFixed(2))
 
 saldo = saldo - amortizacao
 
 listatabela(parc, vparcela, amortizacao,  juros, saldo)
 
 parcelan = parcelan - 1
 
   if (parcelan > 0){
  calculo(parcelan, amortizacao, taxan, saldo, parc)
   }
}
}

function listatabela(parc, vparcela, amortizacao,  juros, saldo) {
  

 let tbod = document.getElementById('tbody')
 var tr = tbod.insertRow()

 var td_parcela = tr.insertCell()
 var td_vparcela = tr.insertCell()
 var td_amort = tr.insertCell()
 var td_juros = tr.insertCell()
 var td_saldo = tr.insertCell()
 
 td_parcela.innerText = parc
 td_vparcela.innerText = vparcela
 td_amort.innerText = +(amortizacao.toFixed(2))
 td_juros.innerText = juros
 td_saldo.innerText = +(saldo.toFixed(2))
 
}
